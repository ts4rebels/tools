**SimsFinds instant redirect**

To use this script first install [Greasemonkey](https://addons.mozilla.org/en-US/firefox/addon/greasemonkey/) (Firefox only), [Violentmonkey](https://violentmonkey.github.io/get-it/) or [Tampermonkey](https://www.tampermonkey.net/).

# [Then click here to install this UserScript!](https://gist.github.com/anadius/38e6509886660b11247e3833663f258a/raw/sims-finds.user.js)