**Patreon bulk attachment downloader**

To use this script first install [Greasemonkey](https://addons.mozilla.org/en-US/firefox/addon/greasemonkey/) (Firefox only), [Violentmonkey](https://violentmonkey.github.io/get-it/) or [Tampermonkey](https://www.tampermonkey.net/).

# [Then click here to install this UserScript!](https://gist.github.com/anadius/94a218da5262735b431eb2b4b3f20d5d/raw/patreon.bulk.user.js)