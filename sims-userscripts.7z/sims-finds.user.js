// ==UserScript==
// @name     SimsFinds instant redirect
// @version  1.0.3
// @match    *://www.simsfinds.com/downloads/*
// @match    *://simsfinds.com/downloads/*
// @match    *://www.simsfinds.com/continue?*
// @match    *://simsfinds.com/continue?*
// @grant    none
// ==/UserScript==

if(window.location.pathname.startsWith("/downloads/")) {
	document.location = document.querySelector("[data-continue]").getAttribute("data-continue");
}
else if(window.location.pathname.startsWith("/continue")) {
  window.setTimeout(`$jBODY.setAttr('at5r243r8', 1);`, 0);
  const interval = window.setInterval(() => {
    const el = document.querySelector('[href*="download?"]');
    if(el !== null) {
      window.clearInterval(interval);
      document.location = el.href;
    }
  }, 10);
}
