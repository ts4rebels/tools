**Around the Sims download helper**

To use this script first install [Greasemonkey](https://addons.mozilla.org/en-US/firefox/addon/greasemonkey/) (Firefox only), [Violentmonkey](https://violentmonkey.github.io/get-it/) or [Tampermonkey](https://www.tampermonkey.net/).

# [Then click here to install this UserScript!](https://gist.github.com/anadius/50daf5e01d0efe5d020bda4e7cc65944/raw/around-the-sims.user.js)