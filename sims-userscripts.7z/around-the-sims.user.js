// ==UserScript==
// @name        Around the Sims download helper
// @description "Donator" button now downloads each items separately and generates a ZIP with them all. Progress displayed in the page title.
// @version     1.0.2
// @grant       none
// @namespace   anadius.github.io
// @match       *://*.aroundthesims3.com/*
// @match       *://aroundthesims3.com/*
// @require     https://cdn.jsdelivr.net/npm/jszip@3.10.0/dist/jszip.min.js
// @require     https://cdn.jsdelivr.net/npm/filesaver.js@1.3.4/FileSaver.min.js
// ==/UserScript==

function blobToBase64(blob) {
  return new Promise((resolve, _) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.readAsDataURL(blob);
  });
}

(() => {
  const allLinks = Array.from(document.querySelectorAll("a[href$='.zip']"));
  if(allLinks.length === 0)
    return;

  const links = [];
  const donatorLinks = [];
  for(const a of allLinks) {
    if(a.href.includes("/donations/")) {
      donatorLinks.push(a);
    }
    else {
      links.push(a);
    }
  }
  const donatorLink = donatorLinks.pop();

  const zipName = donatorLink.href.split("/").pop();
  donatorLink.addEventListener("click", async e => {
    e.preventDefault();

    const oldTitle = document.title;
    let counter = 0;
    const max = links.length;

    const tempZip = new JSZip();
    for(const link of links) {
      try {
        document.title = `${++counter}/${max}`;
        console.log(link, link.href);
        const response = await fetch(link.href);
        const blob = await response.blob();
        const data = await blobToBase64(blob);
        await tempZip.loadAsync(data.replace(/^data:.*?;base64,/, ""), {base64: true});
      }
      catch(e) {
        console.error(e);
        alert("something went wrong, more info in console");
        return;
      }
    }

    document.title = oldTitle;
    tempZip.generateAsync({type:"blob"})
      .then(function(content) {
      saveAs(content, zipName);
    });
  });
})();
