**The Sims Resource download helper**

To use this script first install [Tampermonkey](https://www.tampermonkey.net/). Greasemonkey and Violentmonkey won't work.

# [Then click here to install this UserScript!](https://gist.github.com/anadius/5e4adde476eed1292c258927bc1d05ea/raw/the-sims-resource.user.js)