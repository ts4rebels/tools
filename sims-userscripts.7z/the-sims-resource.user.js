// ==UserScript==
// @name         The Sims Resource download helper
// @description  Automate downloading, download multiple files at once
// @author       anadius
// @namespace    anadius.hermietkreeft.site
// @match        *://www.thesimsresource.com/*
// @match        *://thesimsresource.com/*
// @version      1.0.3
// @grant        GM.xmlHttpRequest
// @grant        GM.getValue
// @grant        GM.setValue
// ==/UserScript==

/* eslint curly: 0 */

// if you set it too low the page will close before the download starts so be careful
const CLOSE_PAGE_AFTER_SECONDS = 5;
// set to true to print the download url in console instead of opening it
const TESTING = false;

const BASE_URL = "https://www.thesimsresource.com";
const AUTO_DOWNLOAD_HASH = "#download-automatically";
const SESSION_COOKIE_NAME = "tsrdlsession";
const TICKET_COOKIE_NAME = "tsrdlticket";
const CSS_FIXES = `
.ad-browse-rectangle-mid, .ad-browse-rectangle-wrapper, .vip-leader, .basketcta-popup,
.basket-button.disabled, .tsrinstall.disabled,
.vip-square, .okletsdothis.dl, .download-details-ad-wrapper, .nonsubscriber.join-vip,
.gift-vip, .tsr-ad, .top-ribbon-content, .top-ribbon-content-mobile,
#pw-oop-bottom_rail, #pw-oop-left_rail, #pw-oop-flex_leaderboard, #pw-oop-flex_leaderboard_container,
body .ad-browse-rectangle,
.pw-ad-scroll-container,
.subscribe-to-results-modal,
.basket-link.nonsubscriber,
.cc-manager-button.nonsubscriber,
.promo,
.text-area .ng-scope[ng-if*="!isVipSubscriber"]
{
  display: none !important;
}
.big-download-buttons .dl, .big-download-buttons .dl-ea {
  width: 100% !important;
}

.thumbnail-popup {
  height: auto;
  padding-bottom: 5px;
}
.mainmenu .signin-buttons {
  border-left: 0;
}
#footer {
  padding-bottom: 0;
}`;

const asyncSleep = (miliseconds, value) => new Promise(resolve => {
  window.setTimeout(resolve, miliseconds, value);
});

const getSessionCookie = () => {
  for(const cookie of document.cookie.split(/\s*;\s*/)) {
    const [name, value] = cookie.split(/\s*=\s*/);
    if(name === SESSION_COOKIE_NAME)
      return value;
  }
  return null;
};

// used for displaying information to user
const [addInfo, removeInfo] = (() => {
  let parentElement = null;

  const add = (textOrElement) => {
    if(parentElement === null) {
      parentElement = document.createElement("div");
      parentElement.style.position = "fixed";
      parentElement.style.top = "0";
      parentElement.style.left = "0";
      parentElement.style.zIndex = "9999999999";
      parentElement.style.background = "white";
      parentElement.style.padding = "20px";
      document.body.append(parentElement);
    }

    const element = document.createElement("div");
    if(typeof textOrElement === "string")
      element.innerHTML = textOrElement;
    else
      element.append(textOrElement);
    parentElement.append(element);
    return element;
  };

  const remove = () => {
    if(parentElement !== null) {
      parentElement.remove();
      parentElement = null;
    }
  };

  return [add, remove];
})();

// same as addInfo but in red
const addError = (text) => {
  const element = addInfo(text);
  element.style.color = "red";
};
// load image and then display it to user
const addImage = (path) => new Promise((resolve) => {
  const img = new Image();
  img.onload = () => {
    addInfo(img);
    resolve();
  };
  img.src = path;
});
// timer
const addTimer = async (miliseconds, text) => {
  const oldTitle = document.title;
  const sleepUntil = Date.now() + miliseconds;
  const span = document.createElement("span");

  const update = (miliseconds) => {
    const seconds = Math.ceil(miliseconds / 1000);
    const fullText = `${text}: ${seconds}`;
    span.innerHTML = fullText;
    document.title = fullText;
  };

  update(miliseconds);
  addInfo(span);
  while(true) {
    const diff = sleepUntil - Date.now();
    if(diff > 0) {
      update(diff);
      await asyncSleep(Math.min(250, diff));
    }
    else
      break;
  }
  update(0);
  document.title = oldTitle;
};

// parse raw headers; return Headers object and an array of cookies set
const getHeaders = rawHeaders => {
  const headers = Array.from(rawHeaders.matchAll(/^(.*?): ?(.*?)$/gm));
  const cookies = [];
  for(const x of headers) {
    x.shift(); // remove the whole match
    // Headers interface removes Set-Cookie headers so store them separately
    if(x[0].toLowerCase() === "set-cookie")
      cookies.push(x[1]);
  }
  return [new Headers(headers), cookies];
};

// fetch-like GM.xhr
const xhr = async (url, options, cookies) => new Promise((resolve, reject) => {
  if(typeof options === "undefined") options = {};

  let {method, headers, referrer, body} = options;
  if(typeof method === "undefined") method = "GET";
  if(typeof headers === "undefined") headers = {};
  if(typeof referrer !== "undefined") headers.Referer = referrer;

  GM.xmlHttpRequest({
    "method": method,
    "url": url,
    "data": body,
    "headers": headers,
    "cookie": cookies,
    "responseType": "blob",
    "onload": res => {
      const [headers, setCookies] = getHeaders(res.responseHeaders)
      const response = new Response(
        res.response,
        {
          "status": res.status,
          "statusText": res.statusText,
          "headers": headers,
        },
      );
      Object.defineProperty(response, "url", {value: res.finalUrl});
      response.setCookies = setCookies;
      resolve(response);
    },
    "onerror": res => {
      console.log(res);
      reject(new Error(`Failed to load ${url}`));
    },
  });
});

// check if response is a captcha page
const captchaNeeded = async (response) => {
  const parser = new DOMParser();
  const htmlDocument = parser.parseFromString(await response.text(), "text/html");
  const captcha = htmlDocument.documentElement.querySelector('input[name="captchavalue"]');
  return captcha !== null;
};

// check if any additional files are required
const getRequired = (data) => {
  const external = (data.requiredDownloadExternalLinks || []).length;
  const internal = (data.requiredDownloads || []).length;
  return (external + internal) > 0;
};

const _downloadItem = async (itemId, close) => {
  const detailsUrl = window.location.href.split("#")[0];
  const thanksUrl = `${BASE_URL}/downloads/thankyou/id/${itemId}`;

  addInfo("initiating download");
  const initResponse = await xhr(
    `${BASE_URL}/ajax.php?c=downloads&a=initDownload&itemid=${itemId}&setItems=&format=zip`,
    {"referrer": detailsUrl},
  );
  let ticketCookie = null;
  // to download multiple files at once we need to store the ticket cookie
  // this requires your UserScript manager to return Set-Cookie headers
  // Greasemonkey doesn't
  // Violentmonkey does, but it doesn't let you set cookies in requests
  for(const cookie of initResponse.setCookies) {
    const pair = cookie.split(/\s*;\s*/)[0];
    const [name, value] = pair.split(/\s*=\s*/);
    if(name === TICKET_COOKIE_NAME) {
      ticketCookie = pair;
      break;
    }
  }
  if(ticketCookie === null) {
    addError("download ticket missing, something's wrong");
    addError("this script will NOT work with Greasemonkey");
    return;
  }

  const initData = await initResponse.json();
  console.log(initData);

  let downloadPageUrl = initData.url;
  if(!downloadPageUrl.startsWith("http"))
    downloadPageUrl = `${BASE_URL}${downloadPageUrl}`;

  addInfo("load download page");
  const downloadPage = await xhr(
    downloadPageUrl,
    {"referrer": detailsUrl},
    ticketCookie,
  );

  if(await captchaNeeded(downloadPage)) {
    addInfo("solve the captcha!");
    await addImage("/downloads/captcha-image");
    await asyncSleep(500);
    const captchaResult = prompt("Solve the captcha and input result here:");
    if(captchaResult === null) {
      addError("okay, no captcha = no download for you");
      return;
    }

    const downloadPage2Promise = xhr(
      downloadPage.url,
      {
        "referrer": downloadPage.url,
        "body": `captchavalue=${captchaResult}`,
        "method": "POST",
        "headers": {
          "Content-Type": "application/x-www-form-urlencoded",
        },
      },
      ticketCookie,
    );
    const downloadPage2 = await Promise.race([downloadPage2Promise, asyncSleep(10000, "TIMED_OUT")]);
    if(downloadPage2 === "TIMED_OUT") {
      throw new Error("Captcha response timed out - try refreshing this page");
    }
    if(await captchaNeeded(downloadPage2)) {
      addError("Captcha solving failed - download one file manually while this script is disabled.");
      return;
    }
    else
      addInfo("captcha solved!");
  }

  // waiting 15 seconds
  const timer = addTimer(15000, "waiting");
  const sessionCookie = getSessionCookie();
  if(sessionCookie !== null)
    await GM.setValue(SESSION_COOKIE_NAME, sessionCookie);
  await timer;

  addInfo("getting download url");
  const getUrlResponse = await xhr(
    `${BASE_URL}/ajax.php?c=downloads&a=getdownloadurl&ajax=1&itemid=${itemId}&mid=0&lk=0`,
    {"referrer": thanksUrl},
    ticketCookie,
  );
  const getUrlData = await getUrlResponse.json();
  console.log(getUrlData);

  if(getUrlData.error.toLowerCase().includes("invalid download ticket")) {
    addError("Invalid download ticket, clear your cookies and try again!");
    alert("Invalid download ticket, clear your cookies and try again!");
  }
  else if(getUrlData.error !== "") {
    addError(`Error: ${getUrlData.error}`);
    alert(getUrlData.error);
  }
  else {
    addInfo("finished!");
    const requireFiles = getRequired(getUrlData.data);
    if(requireFiles)
      close = false;

    if(TESTING) {
      console.log(getUrlData);
      close = false;
    }
    else
      document.location = getUrlData.url;

    if(close) {
      await addTimer(CLOSE_PAGE_AFTER_SECONDS * 1000, "closing in");
      window.close();
    }
    else
      removeInfo();

    if(requireFiles) {
      addError("don't forget to download the required files!");
      document.querySelector("#showrequireditems").click();
      alert("don't forget to download the required files!");
    }
  }
};
const downloadItem = async (itemId, close) => {
  try {
    await _downloadItem(itemId, close);
  }
  catch(error) {
    console.error(error);
    addError(`${error}`);
    alert(error);
  }
};

// modify some CSS
{
  const style = document.createElement("style");
  style.innerHTML = CSS_FIXES;
  document.head.append(style);
}

// some constants we will use later on
const autoDownload = document.location.hash === AUTO_DOWNLOAD_HASH;
const [detailsPage, itemId] = (() => {
  const m = document.location.pathname.match(/\/downloads\/details\/(?:.+?\/)?id\/(\d+)/);
  if(m === null)
    return [false, null];
  else
    return [true, m[1]];
})();

(async () => {
  // restore session cookie if missing
  const sessionCookie = getSessionCookie();
  if(sessionCookie === null) {
    const oldSessionCookie = await GM.getValue(SESSION_COOKIE_NAME, null);
    if(oldSessionCookie !== null)
      document.cookie = `${SESSION_COOKIE_NAME}=${oldSessionCookie}; SameSite=None; Path=/; Domain=.thesimsresource.com`;
  }

  // remove that fucking backtick next to filters
  const element = document.querySelector(".filter-wrap");
  if(element !== null) {
    for(const child of element.childNodes) {
      if(child.nodeType === Node.TEXT_NODE)
        child.nodeValue = child.nodeValue.replace("`", "");
    }
  }
})();

// edit download buttons
for(const downloadButton of document.querySelectorAll("a.download-button")) {
  const prev = downloadButton.previousElementSibling;
  if(downloadButton.classList.contains("vip-exclusive") || (prev !== null && prev.classList.contains("vip-exclusive"))) {
    continue;
  }
  downloadButton.innerHTML = "Download+";
  downloadButton.classList.remove("subonly");
  downloadButton.classList.add("download-now");

  if(downloadButton.parentElement.classList.contains("main-download-buttons")) {
    // main button on details page
    downloadButton.addEventListener("click", e => {
      e.preventDefault();
      e.stopPropagation();
      downloadItem(itemId, false);
    }, true);
  }
  else {
    // browse page and small download buttons on other page
    downloadButton.href += AUTO_DOWNLOAD_HASH;
  }
}
// edit "required" links
for(const requiredLink of document.querySelectorAll('.required-download-item a[href^="/downloads/"]')) {
  if(!requiredLink.href.startsWith(BASE_URL))
    continue;
  const m = new URL(requiredLink.href).pathname.match(/^\/downloads\/(\d+)$/);
  if(m === null)
    continue;
  requiredLink.href = `${BASE_URL}/downloads/details/id/${m[1]}/${AUTO_DOWNLOAD_HASH}`;
}

const observer = new MutationObserver((mutationList, observer) => {
  // editing text triggers the observer, we need those checks to avoid infinite loops
  let shouldProcess = false;
  for(const mutation of mutationList) {
    if(mutation.type !== "childList") {
      return;
    }
    for(const node of mutation.addedNodes) {
      if(node.nodeType === Node.ELEMENT_NODE) {
        shouldProcess = true;
      }
    }
  }
  if(!shouldProcess) {
    return;
  }

  // on collections page
  for(const el of document.querySelectorAll(".download-button.download-now.ng-scope")) {
    el.href += AUTO_DOWNLOAD_HASH;
    el.innerHTML = "Download+";
    el.classList.remove("ng-scope");
  }
  // on main and search pages
  for(const el of document.querySelectorAll(".button.more-details.nonsubscriber")) {
    const eaElement = el.parentElement.querySelector(".early-access");
    const canDownload = (eaElement === null ? true : eaElement.style.display.toLowerCase() === "none");
    if(canDownload) {
      el.innerHTML = "Download+";
      el.classList.add("download-now");
      el.classList.remove("vip-exclusive");
      if(!el.href.includes(AUTO_DOWNLOAD_HASH)) {
        el.href += AUTO_DOWNLOAD_HASH;
      }
    }
    else {
      el.innerHTML = "VIP Exclusive";
      el.classList.add("vip-exclusive");
      el.classList.remove("download-now");
      el.href = "javascript:void(0);";
    }
  }
  
  // cookie consent checkboxes
  for(const cb of document.querySelectorAll('.fc-consent-root input[type="checkbox"]')) {
    if(cb.checked) {
      cb.click();
    }
  }
});
observer.observe(document.body, {childList: true, subtree: true});

// if on details page and auto-download detected in link - start the download
if(detailsPage && autoDownload)
  downloadItem(itemId, true);
