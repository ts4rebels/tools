"""
Quick and dirty script to extract ZIP files when you don't have enough space
for both ZIP and extracted files at the same time.
It extracts files from the end of the ZIP and then removes them from the archive.
Even if you abort with Ctrl+C the ZIP file should be valid.

First parameter is the ZIP file.
Second parameter is the output dir.
"""

import sys
import zipfile

out = sys.argv[2]

with zipfile.ZipFile(sys.argv[1], "a") as zf:
    try:
        zf._didModify = True
        zf.filelist.sort(key=lambda x: x.header_offset)
        while len(zf.filelist) > 0:
            zinfo = zf.filelist.pop()
            print(zinfo.filename)
            zf.extract(zinfo, path=out)
            try:
                zf.start_dir = zinfo.header_offset
                zf.fp.seek(zinfo.header_offset)
                zf.fp.truncate()
            except KeyboardInterrupt:
                zf.start_dir = zinfo.header_offset
                zf.fp.seek(zinfo.header_offset)
                zf.fp.truncate()
                break
    except KeyboardInterrupt:
        pass
