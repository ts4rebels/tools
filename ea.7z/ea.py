import os
import re
import json
import datetime

import requests

from . import (
    timeutils,
    signature,
    utils,
)
from .session import get_legacy_session
from .exceptions import (
    APIError,
    AuthError,
    MalformedConfigError,
)
from .queries import (
    QUERY_DOWNLOAD_URL,
    QUERY_OFFER_DETAILS,
    QUERY_ENTITLEMENTS,
)


CLIENT_SECRET = "4mRLtYMb6vq9qglomWEaT4ChxsXWcyqbQpuBNfMPOYOiDmYYQmjuaBsF2Zp0RyVeWkfqhE9TuGgAw7te"
EA_APP_VERSION = "13.375.0.5888"


class EA:
    def __init__(self, config=None):
        if config is None:
            config = os.path.normpath(
                os.path.expanduser("~/.config/electronic-arts-creds.json"),
            )
        self._config_path = config

        self._session = get_legacy_session()

        data = self._load_data()
        self._ea_app_version = data.get("ea_app_version", EA_APP_VERSION)
        self._ea_app_version_next_check = timeutils.timestamp_to_date(
            data.get("ea_app_version_next_check"),
        )
        self._remid = data.get("remid")
        self._signature_data = data.get("signature_data")
        if self._signature_data is None:
            self._signature_data = signature.generate_signature_data()
        self._access_token = data.get("access_token")
        self._access_token_expiration = timeutils.timestamp_to_date(
            data.get("access_token_expiration"),
        )


    def _load_data(self):
        """Load data from a config file.

        If you want to store the data differently -
        - subclass `EA` and implement this method.
        """
        try:
            with open(self._config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            data = {}
        except json.JSONDecodeError:
            raise MalformedConfigError(self._config_path)

        return data

    def _save_data_(self, data):
        with open(self._config_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def _save_data(self, data):
        """Save data to a config file.

        If you want to store the data differently -
        - subclass `EA` and implement this method.
        """
        try:
            self._save_data_(data)
        except FileNotFoundError:
            os.makedirs(os.path.dirname(self._config_path), exist_ok=True)
            self._save_data_(data)

    def _save(self):
        self._save_data({
            "ea_app_version": self._ea_app_version,
            "ea_app_version_next_check": timeutils.date_to_timestamp(
                self._ea_app_version_next_check,
            ),
            "remid": self._remid,
            "signature_data": self._signature_data,
            "access_token": self._access_token,
            "access_token_expiration": timeutils.date_to_timestamp(
                self._access_token_expiration,
            ),
        })

    @property
    def ea_app_version(self):
        if self._ea_app_version_next_check < timeutils.now():
            r = requests.get(
                "https://autopatch.juno.ea.com/autopatch/upgrade/buckets/10",
                headers={
                    "User-Agent": "Mozilla/5.0",
                },
            )
            data = r.json()

            self._ea_app_version = data["recommended"]["version"]
            self._ea_app_version_next_check = (
                timeutils.now() + datetime.timedelta(days=7)
            )
            self._save()

        return self._ea_app_version

    @property
    def remid(self):
        if self._remid is None:
            raise AuthError("remid cookie not set!")

        return self._remid

    @remid.setter
    def remid(self, value):
        self._remid = value
        self._save()

    def _fetch_login_code(self, code_challenge, version=0):
        r = self._session.get(
            "https://accounts.ea.com/connect/auth",
            params={
                "code_challenge": code_challenge,
                "code_challenge_method": "S256",
                "client_id": "JUNO_PC_CLIENT",
                "response_type": "code id_token",
                "redirect_uri": "qrc:///html/login_successful.html",
                "display": "junoClient/login",
                "locale": "en_US",
                "nonce": utils.generate_nonce(),
                "pc_sign": signature.generate_signature(
                    version,
                    self._signature_data,
                ),
                "sbiod_enabled": "true",
            },
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    f"Origin/10.6.0.00000 EAApp/{self.ea_app_version} "
                    "Chrome/109.0.5414.120 Safari/537.36"
                ),
                "Cookie": f"remid={self.remid}",
            },
            allow_redirects=False,
        )
        # save remid even if it's missing - that means it expired anyway
        self._remid = r.cookies.get("remid")
        self._save()

        if self._remid is None:
            raise AuthError("Bad or expired remid cookie.")

        # get login code from Location header
        m = re.search(r"#code=(.*?)&", r.headers.get("Location", ""))
        if m is not None:
            return m.group(1)

        try:
            data = r.json()
        except:
            pass
        else:
            if version == 0 and data.get("code") == 102105:
                # bad signature, use another version
                return self._fetch_login_code(code_challenge, version=1)

        raise AuthError("Authentication error!", r)

    def _fetch_access_token(self, code_verifier, code):
        r = self._session.post(
            "https://accounts.ea.com/connect/token",
            headers={
                "User-Agent": (
                    "Mozilla/5.0 EA Download Manager "
                    "Origin/10.6.0.00000"
                ),
            },
            data={
                "grant_type": "authorization_code",
                "code": code,
                "code_verifier": code_verifier,
                "token_format": "JWS",
                "client_id": "JUNO_PC_CLIENT",
                "client_secret": CLIENT_SECRET,
                "redirect_uri": "qrc:///html/login_successful.html",
            },
            allow_redirects=False,
        )
        if r.status_code != 200:
            raise AuthError("Failed fetching access token!", r)
        try:
            data = r.json()
        except:
            raise AuthError("Result is not JSON!", r)

        error = data.get("error")
        if error is None:
            try:
                return data["access_token"], int(data["expires_in"])
            except KeyError:
                error = "access token missing"
        raise AuthError(f"Authentication error: {error}.", r)

    def fetch_access_token(self):
        """Fetch access token, even if the current one is still valid."""
        now = timeutils.now()

        code_verifier, code_challenge = utils.generate_challenge()

        code = self._fetch_login_code(code_challenge)
        token, expires_in = self._fetch_access_token(code_verifier, code)

        self._access_token = token
        self._access_token_expiration = now + datetime.timedelta(
            seconds=expires_in,
        )
        self._save()

        return self._access_token

    @property
    def access_token(self):
        if (
            self._access_token is not None
            and self._access_token_expiration > timeutils.now()
        ):
            return self._access_token

        return self.fetch_access_token()

    def _api_request(self, query, variables=None, needs_auth=False):
        headers = {
            "User-Agent": f"EAApp/PC/{self.ea_app_version}",
            "x-client-id": "EAX-JUNO-CLIENT",
            "Accept": "application/json",
        }
        if needs_auth:
            headers["Authorization"] = f"Bearer {self.access_token}"

        payload = {
            "query": query,
        }
        if variables is not None:
            payload["variables"] = variables

        r = self._session.post(
            "https://service-aggregation-layer.juno.ea.com/graphql",
            headers=headers,
            json=payload,
        )

        try:
            r.raise_for_status()
            print(json.dumps(r.json(), indent=2))
            return r.json()["data"]
        except:
            raise APIError("API error.", r)

    def get_download_urls(self, offer_id):
        data = self._api_request(
            QUERY_DOWNLOAD_URL,
            variables={
                "fetchArchiveSize": True,
                "fetchSyncPackage": True,
                "fetchSyncSize": False,
                "offerId": offer_id,
            },
            needs_auth=True,
        )
        return data["jitUrl"]

    def get_game_info(self, *offer_ids):
        return self._api_request(
            QUERY_OFFER_DETAILS,
            variables={
                "locale": "DEFAULT",
                "offerIds": offer_ids,
            },
        )

    def get_entitlements(self):
        entitlements = []
        i = 1
        while True:
            data = self._api_request(
                QUERY_ENTITLEMENTS,
                variables={
                    "pageSize": 100,
                    "pageNumber": i,
                },
                needs_auth=True,
            )
            chunk = data["me"]["sdkEntitlements"]["entitlements"]
            entitlements.extend(chunk)
            if len(chunk) < 100:
                break

        return entitlements
