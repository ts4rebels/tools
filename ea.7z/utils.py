import os
import hashlib
import base64
import random


def url_base64(data):
    if isinstance(data, str):
        data = data.encode()
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def generate_challenge():
    code_verifier = url_base64(os.urandom(32))
    return (
        code_verifier,
        url_base64(hashlib.sha256(code_verifier.encode()).digest()),
    )


def generate_nonce():
    return random.randint(-2147483648, 2147483647)
