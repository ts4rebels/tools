import ssl
import urllib3
import requests


class TimeoutHTTPAdapter(requests.adapters.HTTPAdapter):
    def __init__(self, ssl_context, timeout, *args, **kwargs):
        self.ssl_context = ssl_context
        self.timeout = timeout
        super().__init__(*args, **kwargs)

    def send(self, request, **kwargs):
        timeout = kwargs.get("timeout")
        if timeout is None:
            kwargs["timeout"] = self.timeout
        return super().send(request, **kwargs)

    def init_poolmanager(self, connections, maxsize, block=False):
        self.poolmanager = urllib3.poolmanager.PoolManager(
            num_pools=connections, maxsize=maxsize,
            block=block, ssl_context=self.ssl_context)


def get_legacy_session():
    ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    ctx.options |= 0x4  # OP_LEGACY_SERVER_CONNECT
    session = requests.Session()
    adapter = TimeoutHTTPAdapter(
        ctx,
        30,
        max_retries=requests.adapters.Retry(5, backoff_factor=1),
    )
    session.mount("https://", adapter)
    return session
