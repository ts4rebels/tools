import datetime
import json
import random
import string
import hashlib

from .utils import url_base64


PC_SIGN_XORS = [
    b"nt5FfJbdPzNcl2pkC3zgjO43Knvscxft",
    b"ISa3dpGOc8wW7Adn4auACSQmaccrOyR2",
]
# I just took some GPUs from Steam hardware survey
GPUS = [
    0x1C21,  # NVIDIA GeForce GTX 1050 Ti
    0x1C00,  # NVIDIA GeForce GTX 1060
    0x1F9D,  # NVIDIA GeForce GTX 1650
    0x21C4,  # NVIDIA GeForce GTX 1660 Super
    0x2191,  # NVIDIA GeForce GTX 1660 Ti
    0x1F08,  # NVIDIA GeForce RTX 2060
    0x25A2,  # NVIDIA GeForce RTX 3050 Laptop GPU
    0x2503,  # NVIDIA GeForce RTX 3060
    0x2520,  # NVIDIA GeForce RTX 3060 Laptop GPU
    0x2486,  # NVIDIA GeForce RTX 3060 Ti
    0x2484,  # NVIDIA GeForce RTX 3070
]


def generate_signature(version, signature_data):
    pc_sign_data = signature_data.copy()
    # generate timestamp
    n = datetime.datetime.utcnow()
    pc_sign_data["ts"] = (
        f"{n.year}-{n.month}-{n.day} "
        f"{n.hour}:{n.minute}:{n.second}:{n.microsecond // 1000}"
    )
    tmp = url_base64(json.dumps(pc_sign_data, separators=(",", ":")))
    return f"{tmp}.{generate_signature_hash(version, tmp)}"


def generate_signature_hash(version, signature):
    xor1 = [54] * 64  # ord("6") = 54
    xor2 = [92] * 64  # ord("\\") = 92
    for i, character in enumerate(PC_SIGN_XORS[version]):
        xor1[i] ^= character
        xor2[i] ^= character

    hash1 = hashlib.sha256(bytes(xor1))
    hash1.update(signature.encode())
    hash2 = hashlib.sha256(bytes(xor2))
    hash2.update(hash1.digest())
    return url_base64(hash2.digest())


def generate_signature_data():
    def generate_number(digits):
        return "".join(random.choices(string.digits, k=digits))


    def generate_letter(characters):
        return "".join(random.choices(string.ascii_lowercase, k=characters))


    def generate_mac():
        mac = "$"
        for _ in range(6):
            mac += f"{random.randint(0, 255):02x}"
        return mac

    return {
        "av": "v1",
        "bsn": generate_number(13),
        "gid": random.choice(GPUS),
        "hsn": generate_number(1) + generate_letter(1) + generate_number(10),
        "mac": generate_mac(),
        "mid": generate_number(19),
        "msn": generate_letter(2) + generate_number(8),
        "sv": "v2",
        # "ts": "2023-6-5 12:8:37:0",  # timestamp is added later
    }
