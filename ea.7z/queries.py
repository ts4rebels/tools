QUERY_DOWNLOAD_URL = """
query JitUrlRequest (
  $offerId: String!,
  $cdnOverride: String,
  $fetchArchiveSize: Boolean!,
  $fetchSyncPackage: Boolean!,
  $fetchSyncSize: Boolean!
){
  jitUrl: downloadUrl(offerId:$offerId, cdnOverride:$cdnOverride) {
    url
    archiveSize @include(if:$fetchArchiveSize)
    syncUrl @include(if:$fetchSyncPackage)
    syncArchiveSize @include(if:$fetchSyncSize)
  }
}
"""

QUERY_OFFER_DETAILS = """
query getLegacyCatalogDefs($offerIds: [String!]!, $locale: Locale) {
  legacyOffers(offerIds: $offerIds, locale: $locale) {
    offerId: id
    contentId
    basePlatform
    primaryMasterTitleId
    mdmProjectNumber
    achievementSetOverride
    gameLauncherURL
    gameLauncherURLClientID
    stagingKeyPath
    mdmTitleIds
    multiplayerId
    executePathOverride
    installationDirectory
    installCheckOverride
    monitorPlay
    displayName
    displayType
    igoBrowserDefaultUrl
    executeParameters
    softwareLocales
    dipManifestRelativePath
    metadataInstallLocation
    distributionSubType
    downloads {
      igoApiEnabled
      downloadType
      version
      executeElevated
      buildReleaseVersion
      buildLiveDate
      buildMetaData
      gameVersion
      treatUpdatesAsMandatory
      enableDifferentialUpdate
    }
    locale
    greyMarketControls
    isDownloadable
    isPreviewDownload
    downloadStartDate
    releaseDate
    useEndDate
    subscriptionUnlockDate
    subscriptionUseEndDate
    softwarePlatform
    softwareId
    downloadPackageType
    installerPath
    processorArchitecture
    macBundleID
    gameEditionTypeFacetKeyRankDesc
    appliedCountryCode
    cloudSaveConfigurationOverride
    firstParties{
      partner
      partnerId
      partnerIdType
    }
    suppressedOfferIds
  }
  gameProducts(offerIds: $offerIds, locale: $locale) {
    items {
      name
      originOfferId
      baseItem {
        title
        regionalRatingV2 {
          ageRating {
            minAge
          }
        }
      }
      gameSlug
      lifecycleStatus {
        lifecycleType
        revealDate
        playableStartDate
        playableEndDate
        downloadDate
      }
    }
  }
}
"""

QUERY_ENTITLEMENTS = """
query sdkEntitlements($pageSize: Int, $pageNumber: Int) {
  me {
    sdkEntitlements(
      productIds: [],
      includeChildGroups: true,
      groupNames: [],
      entitlementTag: "",
      paging: {
        pageSize: $pageSize, pageNumber : $pageNumber
      }
    ) {
      entitlements {
        entitlementTag
        entitlementType
        grantDate
        groupName
        id
        productId
        terminationDate
        useCount
        version
      }
    }
  }
}
"""
