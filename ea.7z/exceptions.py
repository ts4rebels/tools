class ExceptionWithResponse(Exception):
    def __init__(self, message, response=None):
        if response is not None:
            message = (
                f"{response.status_code=}\n{response.headers=}\n{response.text=}"
                f"\n\n{message} Details above might help to fix it."
            )
        super().__init__(message)


class APIError(ExceptionWithResponse):
    pass


class AuthError(ExceptionWithResponse):
    pass


class MalformedConfigError(Exception):
    def __init__(self, path):
        super().__init__(f"Config file is not a valid JSON file: {path}")
        self.filename = path
