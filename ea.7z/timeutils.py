import datetime

DATE_FORMAT = "%Y-%m-%d %H:%M:%S.%f%z"


def now():
    return datetime.datetime.now().astimezone()


def date_to_timestamp(date):
    return date.strftime(DATE_FORMAT)


def timestamp_to_date(timestamp):
    if timestamp is None:
        return datetime.datetime(2000, 1, 1).astimezone()

    return datetime.datetime.strptime(timestamp, DATE_FORMAT).astimezone()
